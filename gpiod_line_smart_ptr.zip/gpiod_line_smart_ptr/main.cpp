/*************************************************************************************
* Implementering av smarta pekare i ett flertr�dat program. Smarta pekare anv�nds
* f�r dynamiskt allokerat minne i C++ f�r att unvika minnesl�ckor genom att minnet
* i fr�ga frig�rs automatiskt av klassens destruktor ifall ett givet objekt g�r
* ur scope. Inneh�llet som pekas p� kan erh�llas via anrop av medlemsfunktionen get.
* 
* I detta program anv�nds smarta pekare i tre processer, varav tv� GPIO-processer
* samt en inmatningsprocess. Varje GPIO-process inneh�ller smarta GPIO-linjepekare
* f�r en lysdiod samt en tryckknapp, en f�rdr�jningstid f�r blinkning samt en 
* enable-signal. Vid nedtryckning av tryckknappen eller d� enable-signaler �r true
* blinkar lysdioden, annars h�lls den sl�ckt. Enable-signalen kontrolleras fr�n
* inmatningsprocessen, d�r anv�ndaren kan toggla denna genom att mata in lysdiodens
* alias.
* 
* Kompilera programmet och skapa en k�rbar fil via f�ljande kommando:
* $ g++ main.cpp -o main -Wall -l gpiod -l pthread
* 
* K�r sedan programmet via f�ljande kommando:
* $ ./main
**************************************************************************************/

/* Inkluderingsdirektiv: */
#include <iostream>
#include <string>
#include <thread>
#include "gpio.hpp"

/*************************************************************************************
* gpio_process: Blinkar angiven lysdiod vid nedtryckning av angiven tryckknapp eller
*               ifall angiven enable-signal �r true (kontrolleras externt). Annars
*               h�lls lysdioden sl�ckt.
**************************************************************************************/
static void gpio_process(gpio::gpiod_line_ptr& led, gpio::gpiod_line_ptr& button,
   bool& enabled, const std::size_t delay_time)
{
   while (true)
   {
      if (enabled || gpiod_line_get_value(button.get()) == 1)
      {
         gpiod_line_set_value(led.get(), 1);
         usleep(delay_time * 1000);
         gpiod_line_set_value(led.get(), 0);
         usleep(delay_time * 1000);
      }

      else
      {
         gpiod_line_set_value(led.get(), 0);
      }
   }

   return;
}

/*************************************************************************************
* read_process: Togglar enable-signaler f�r tv� lysdioder via inmatning av deras
*               respektive alias. Instruktioner skrivs ut i terminalen innan
*               inmatningen p�b�rjas.
**************************************************************************************/
static void read_process(const gpio::gpiod_line_ptr& led1, const gpio::gpiod_line_ptr& led2,
   bool& enabled1, bool& enabled2)
{
   std::string s;
   std::cout << "Enter " << gpiod_line_consumer(led1.get()) << " to toggle the led connected "
      "to pin " << gpiod_line_offset(led1.get()) << "!\n";
   std::cout << "Enter " << gpiod_line_consumer(led2.get()) << " to toggle the led connected "
      "to pin " << gpiod_line_offset(led2.get()) << "!\n\n";

   while (true)
   {
      std::getline(std::cin, s);

      if (s == gpiod_line_consumer(led1.get()))
      {
         enabled1 = !enabled1;
         std::cout << "Toggling " << gpiod_line_consumer(led1.get()) << "!\n\n";
      }
      else if (s == gpiod_line_consumer(led2.get()))
      {
         enabled2 = !enabled2;
         std::cout << "Toggling " << gpiod_line_consumer(led2.get()) << "!\n\n";
      }
   }

   return;
}

/*************************************************************************************
* main: Ansluter tv� lysdioder till PIN 17 och 22 samt tv� tryckknappar till PIN
*       23 samt 27 och implementerar dessa via smarta pekare. Smarta pekare led1,
*       led2 samt button1 initieras direkt genom att passera PIN-nummer, datariktning
*       och alias, medan button2 initieras manuellt via en GPIO-linjepekare, vars
*       adress sedan passeras till konstruktorn f�r klassen gpiod_line_ptr. Syftet
*       med detta �r att visa tv� s�tt att initiera smarta GPIO-linjepekare, d�r
*       det f�rsta alternativet �r enklare och rekommenderas. F�r att demonstrera
*       f�rflyttningskonstruktorer via funktionen std::move, s� f�rflyttas minnet
*       f�r objektet led2 till ett nytt objekt led3, som sedan anv�nds i resterande
*       program. Minnet f�r led2 kan t�nkas byta �gare till led3, vilket inneb�r att
*       led2 efter flytten �r tom och pekare inte l�ngre p� minnet. F�rflyttningen av
*       minnet m�jligg�rs av f�rflyttningskonstruktorn i klassen gpiod_line_ptr.
* 
*       De smarta pekarna samt tv� enable-variabler anv�nds f�r att implementera tre
*       tr�dar, varav tv� anv�nds f�r GPIO-kontroll av lysdioderna via tryckknapparna, 
*       medan den tredje anv�nds f�r att l�sa inmatning fr�n tangentbordet, vilket
*       kan anv�ndas f�r att toggla enable-variablerna f�r lysdioderna.
* 
**************************************************************************************/
int main(void)
{
   gpio::gpiod_line_ptr led1(17, gpio::direction::out, "led1");
   gpio::gpiod_line_ptr led2(22, gpio::direction::out, "led2");
   gpio::gpiod_line_ptr button1(23, gpio::direction::in, "button1");
   auto led3 = std::move(led2);

   gpiod_line* button2_line = gpiod_chip_get_line(gpio::chip0, 27);
   gpiod_line_request_output(button2_line, "button2", 0);
   gpio::gpiod_line_ptr button2(&button2_line);

   bool enabled1 = false, enabled2 = false;

   std::thread t1(&gpio_process, std::ref(led1), std::ref(button1), std::ref(enabled1), 100);
   std::thread t2(&gpio_process, std::ref(led3), std::ref(button2), std::ref(enabled2), 500);
   std::thread t3(&read_process, std::ref(led1), std::ref(led3), std::ref(enabled1), std::ref(enabled2));

   t1.join();
   t2.join();
   t3.join();
   return 0;
}