#ifndef GPIO_HPP_
#define GPIO_HPP_

/* Inkluderingsdirektiv: */
#include <iostream>
#include <gpiod.h>
#include <unistd.h>

/*************************************************************************************
gpio: Namnrymd inneh�llande funktionalitet f�r GPIO-implementering med smarta pekare.
**************************************************************************************/
namespace gpio
{
   enum class direction { in, out }; // Datariktning.
   class gpiod_line_ptr; // Klass f�r smarta GPIO-linjepekare.
   gpiod_chip* chip0 = gpiod_chip_open("/dev/gpiochip0"); // Pekare till gpiochip0.
}

/*************************************************************************************
* gpiod_line_ptr: Implementering av smarta pekare specifikt avsett f�r GPIO-linjer. 
*                 Objekt av denna klass utg�r en typ av unika pekare, d� minnet f�r
*                 dem �r unikt f�r varje objekt och kan d�rmed varken kopieras,
*                 f�rflyttas eller tilldelas fr�n ett annat objekt.
**************************************************************************************/
class gpio::gpiod_line_ptr
{
protected:
   gpiod_line* m_line = nullptr; // Aktuell GPIO-linjepekare.
public:
   gpiod_line_ptr(void) { }

   /*************************************************************************************
   * gpiod_line_ptr: Konstruktor, lagrar adressen till given GPIO-linjepekare, som
   *                 m�ste initieras av anv�ndaren innan konstruktorn anropas.
   **************************************************************************************/
   gpiod_line_ptr(gpiod_line** line) { this->m_line = *line; }

   /*************************************************************************************
   * gpiod_line_ptr: Konstruktor, initierar ny GPIO-linjepekare, s�tter datariktning,
   *                 samt angivet alias och startv�rde ifall detta har specificerats.
   **************************************************************************************/
   gpiod_line_ptr(const std::uint8_t pin, const gpio::direction direction,
      const char* alias = nullptr, const int start_val = 0)
   {
      this->m_line = gpiod_chip_get_line(gpio::chip0, pin);

      if (direction == gpio::direction::out)
      {
         gpiod_line_request_output(this->m_line, alias, start_val);
      }
      else
      {
         gpiod_line_request_input(this->m_line, alias);
      }

      return;
   }

   /*************************************************************************************
   * ~gpiod_line_ptr: Destruktor, tas bort reservation av aktuell GPIO-linje och 
   *                  s�tter tillh�rande GPIO-linjepekare till null.
   **************************************************************************************/
   ~gpiod_line_ptr(void) { gpiod_line_release(this->m_line); this->m_line = nullptr; }

   /*************************************************************************************
   * get: Returnerar GPIO-linjepekare f�r anv�ndning, exempelvis f�r att s�tta utsignal.
   **************************************************************************************/
   gpiod_line* get(void) const { return this->m_line; };

   /*************************************************************************************
   * Raderar kopierings- samt tilldelningsoperatorn s� att aktuellt objekt �r unikt; 
   * minnet kan inte kopieras och aktuellt objekt kan inte heller tilldelas fr�n ett 
   * annat befintligt objekt. Objekt av klassen gpiod_line_ptr utg�r d�rmed unika pekare.
   * Minnet kan dock f�rflyttas fr�n ett objekt till ett annat via funktionen std::move.
   * 
   * I C++ anv�nds klassen std::unique_ptr fr�n biblioteket memory f�r att �stadkomma
   * mer generella unika pekare, medan gpiod_line_ptr utg�r unika pekare specfikt
   * �mnat f�r GPIO-linjer.
   **************************************************************************************/
   gpiod_line_ptr(gpiod_line_ptr&) = delete; // Kopieringskonstruktor raderad.
   gpiod_line_ptr& operator = (gpiod_line_ptr&) = delete; // Tilldelningsoperator raderad.

   /*************************************************************************************
   * gpiod_line_ptr: F�rflyttningskonstruktor, m�jligg�r att minnet f�r objektet source
   *                 f�rflyttas till aktuellt objekt som this pekar p� via anrop av
   *                 funktionen std::move. Minnet byter d� �gare fr�n source till 
   *                 aktuellt objekt. Efter att minnet har f�rflyttats s� nollst�lls 
   *                 source (medlemmen m_line s�tts till null), s� att denna inte l�ngre 
   *                 pekar p� aktuellt minne. Nyckelordet noexcept anv�nds f�r att
   *                 indikera att f�rflyttningskonstruktorn ej kan generera undantag,
   *                 vilket m�jligg�r att kompilatorn kan genomf�ra vissa optimeringar.
   **************************************************************************************/
   gpiod_line_ptr(gpiod_line_ptr&& source) noexcept
   {
      this->m_line = source.m_line; 
      source.m_line = nullptr;
   }
};

#endif /* GPIO_HPP_ */